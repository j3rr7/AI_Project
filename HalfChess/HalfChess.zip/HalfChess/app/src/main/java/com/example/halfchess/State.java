package com.example.halfchess;

public class State {

    Papan[][] papan;

    public int BoardEvaluation(){

        return 0;
    }
}
